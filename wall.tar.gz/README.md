Autotranslated Wall
===

# Hack

## Dependencies

	sudo npm install -g nodemon
	sudo apt-get install mongodb


## Run the application

Retrieve the project :

```
git clone git@github.com:simonrenoult/autotranslated-wall.git
cd autotranslated-wall
```

Install the dependencies :

```
npm run-script setup
```

Run the server locally :

```
npm run-script dev
```
